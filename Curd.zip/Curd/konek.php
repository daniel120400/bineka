<?php
    $conect = mysqli_connect("127.0.0.1:3307", "root", "", "pertemuan_5");
?>